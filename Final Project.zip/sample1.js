// JavaScript Document

var person = {
	firstName: "Rick"
	lastName: "Colgan"
};
var template = "<h1>{{firstName}} {{lastName}}</h1>";
var html = Mustache.to_html(template, person);
$('sampleArea').html(html);
